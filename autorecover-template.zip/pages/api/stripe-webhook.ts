import { NextApiRequest, NextApiResponse } from "next";
import Stripe from "stripe";
import { buffer } from "micro";

export const config = { api: { bodyParser: false } };

// In-memory demo stats (will reset on cold start)
const recoverStats = {
  totalRecovered: 0,
  retries: 0,
  failedPayments: [] as {
    invoiceId: string;
    customerEmail: string;
    recoveryLink: string;
    retries: number;
    recovered: boolean;
  }[],
};

export type FailedPayment = typeof recoverStats.failedPayments[number];

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" });
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end("Method Not Allowed");

  try {
    const sig = req.headers["stripe-signature"] as string;
    const buf = await buffer(req);
    const event = stripe.webhooks.constructEvent(buf, sig, endpointSecret);

    if (event.type === "invoice.payment_failed") {
      const invoice = event.data.object as Stripe.Invoice;
      const email =
        (invoice.customer_email as string) ||
        (typeof invoice.customer === "string" ? invoice.customer : "unknown@example.com");

      const recoveryLink =
        (invoice.hosted_invoice_url as string) ||
        `https://dashboard.stripe.com/invoices/${invoice.id}/pay`;

      if (!recoverStats.failedPayments.find(f => f.invoiceId === invoice.id)) {
        recoverStats.failedPayments.push({
          invoiceId: invoice.id,
          customerEmail: email,
          recoveryLink,
          retries: 0,
          recovered: false,
        });
      }
      console.log(`[AutoRecover] Payment failed: ${invoice.id} (${email}) → ${recoveryLink}`);
    }

    return res.json({ received: true });
  } catch (err: any) {
    console.error("Stripe signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
}

// Helper getter for dashboard route
export function getRecoverStats() {
  return recoverStats;
}
