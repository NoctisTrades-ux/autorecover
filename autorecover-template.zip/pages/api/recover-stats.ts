import { NextApiRequest, NextApiResponse } from "next";
import { getRecoverStats } from "./stripe-webhook";

export default function handler(_req: NextApiRequest, res: NextApiResponse) {
  const stats = getRecoverStats();
  res.status(200).json(stats);
}
